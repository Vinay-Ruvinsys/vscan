from __future__ import annotations

import argparse
import asyncio
import json
import re
from collections import deque
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag

from playwright.async_api import async_playwright


SECURITY_HEADERS = {
    "content-security-policy": ("Missing Content-Security-Policy", "medium"),
    "strict-transport-security": ("Missing Strict-Transport-Security", "medium"),
    "x-content-type-options": ("Missing X-Content-Type-Options", "low"),
    "referrer-policy": ("Missing Referrer-Policy", "low"),
    "permissions-policy": ("Missing Permissions-Policy", "low"),
}
SENSITIVE_INPUT = re.compile(r"password|passwd|token|secret|api[_-]?key", re.I)


def origin(url: str) -> tuple[str, str, int | None]:
    p = urlparse(url)
    return p.scheme, (p.hostname or "").lower(), p.port


def add_finding(findings, severity, title, url, evidence, recommendation):
    findings.append({
        "severity": severity, "title": title, "url": url,
        "evidence": evidence, "recommendation": recommendation
    })


async def inspect_page(page, url, response, findings):
    headers = {k.lower(): v for k, v in (response.headers.items() if response else [])}

    if urlparse(url).scheme != "https":
        add_finding(findings, "high", "Page is served over HTTP", url,
                    "The page URL does not use HTTPS.",
                    "Serve the application over HTTPS and redirect HTTP to HTTPS.")

    for header, (title, severity) in SECURITY_HEADERS.items():
        if not headers.get(header):
            add_finding(findings, severity, title, url,
                        f"Response did not include {header}.",
                        f"Review and configure the {header} response header.")

    # Cookie values are never collected or reported; only attributes are inspected.
    for cookie in headers.get("set-cookie", "").split("\n"):
        if not cookie.strip():
            continue
        lower = cookie.lower()
        name = cookie.split("=", 1)[0].strip()
        if urlparse(url).scheme == "https" and "secure" not in lower:
            add_finding(findings, "medium", "Cookie missing Secure attribute", url,
                        f"Cookie '{name}' does not show the Secure attribute.",
                        "Set Secure on cookies that should only travel over HTTPS.")
        if "httponly" not in lower:
            add_finding(findings, "medium", "Cookie missing HttpOnly attribute", url,
                        f"Cookie '{name}' does not show the HttpOnly attribute.",
                        "Set HttpOnly on session and other sensitive cookies where JavaScript access is unnecessary.")
        if "samesite" not in lower:
            add_finding(findings, "low", "Cookie missing SameSite attribute", url,
                        f"Cookie '{name}' does not show a SameSite attribute.",
                        "Set an appropriate SameSite policy and validate cross-site flows.")

    dom = await page.evaluate("""() => {
      const abs = v => { try { return new URL(v, location.href).href; } catch(e) { return ''; } };
      return {
        mixed: [...document.querySelectorAll('script[src],link[href],img[src],iframe[src]')]
          .map(e => e.src || e.href).filter(v => v && location.protocol === 'https:' && new URL(v, location.href).protocol === 'http:'),
        passwordForms: [...document.querySelectorAll('form')].filter(f => f.querySelector('input[type=password]'))
          .map(f => ({action: abs(f.getAttribute('action') || location.href), method: (f.method || 'get').toUpperCase()})),
        externalBlank: [...document.querySelectorAll('a[target=_blank]')]
          .filter(a => !a.rel.split(/\\s+/).includes('noopener')).length,
        forms: [...document.forms].map(f => abs(f.getAttribute('action') || location.href)),
        links: [...document.querySelectorAll('a[href]')].map(a => abs(a.href)),
        sensitiveNames: [...document.querySelectorAll('input[name],textarea[name]')]
          .map(e => e.name).filter(n => /password|passwd|token|secret|api[_-]?key/i.test(n))
      };
    }""")

    if dom["mixed"]:
        add_finding(findings, "medium", "Mixed-content resources", url,
                    f"{len(dom['mixed'])} HTTP resource(s) referenced by an HTTPS page.",
                    "Load all scripts, stylesheets, images and frames over HTTPS.")
    for form in dom["passwordForms"]:
        if urlparse(url).scheme != "https" or origin(form["action"])[0] != "https":
            add_finding(findings, "high", "Password form may submit insecurely", url,
                        f"Password form submits via {form['method']} to {form['action']}.",
                        "Use HTTPS for the page and form destination; avoid GET for credentials.")
    if dom["externalBlank"]:
        add_finding(findings, "low", "External links may lack rel=noopener", url,
                    f"{dom['externalBlank']} link(s) use target=_blank without noopener.",
                    "Add rel=\"noopener\" (and optionally noreferrer) to target=_blank links.")
    if dom["sensitiveNames"]:
        add_finding(findings, "info", "Potentially sensitive input names detected", url,
                    "Input field names suggest sensitive data; values were not read.",
                    "Confirm sensitive data is handled server-side and never exposed in URLs or logs.")

    return [link for link in dom["links"] if link]


async def scan(args):
    start = args.url.rstrip("/")
    start_origin = origin(start)
    if start_origin[0] not in ("http", "https") or not start_origin[1]:
        raise ValueError("Provide a valid http:// or https:// URL.")

    findings, visited = [], set()
    queue = deque([start])
    page_summaries = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=not args.headed)
        context_args = {}
        if args.storage_state:
            context_args["storage_state"] = args.storage_state
        context = await browser.new_context(**context_args)
        page = await context.new_page()
        page.set_default_timeout(15000)

        while queue and len(visited) < args.max_pages:
            current = urldefrag(queue.popleft())[0]
            if current in visited or origin(current) != start_origin:
                continue
            visited.add(current)
            try:
                response = await page.goto(current, wait_until="domcontentloaded")
                await page.wait_for_timeout(500)
                await inspect_page(page, current, response, findings)
                links = await page.evaluate("""() => [...document.querySelectorAll('a[href]')].map(a => a.href)""")
                page_summaries.append({
                    "url": current,
                    "status": response.status if response else None,
                    "title": await page.title()
                })
                for link in links:
                    clean = urldefrag(link)[0]
                    if clean and origin(clean) == start_origin and clean not in visited and len(queue) < args.max_pages * 5:
                        queue.append(clean)
            except Exception as exc:
                add_finding(findings, "info", "Page could not be inspected", current,
                            f"{type(exc).__name__}: {str(exc)[:180]}",
                            "Check whether the page requires authentication or blocks browser navigation.")
        await context.close()
        await browser.close()

    # De-duplicate repeated findings across repeated page visits.
    unique = {}
    for f in findings:
        key = (f["severity"], f["title"], f["url"], f["evidence"])
        unique[key] = f

    report = {
        "target": start,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "pages_scanned": len(page_summaries),
        "pages": page_summaries,
        "findings": list(unique.values()),
        "scope_note": "Passive, non-destructive checks only. No fuzzing, exploit attempts, brute force, or state-changing requests."
    }
    Path(args.out).write_text(json.dumps(report, indent=2), encoding="utf-8")
    write_html(report, Path(args.out).with_suffix(".html"))
    return report


def write_html(report, path):
    rows = []
    for f in report["findings"]:
        rows.append(
            "<tr><td>{}</td><td>{}</td><td><a href=\"{}\">{}</a></td><td>{}</td><td>{}</td></tr>".format(
                escape(f["severity"].upper()), escape(f["title"]),
                escape(f["url"], quote=True), escape(f["url"]),
                escape(f["evidence"]), escape(f["recommendation"])
            )
        )
    html = """<!doctype html><html><head><meta charset="utf-8">
    <title>Mini Web Security Agent Report</title>
    <style>body{font:14px Arial;margin:28px;color:#222}table{border-collapse:collapse;width:100%}
    th,td{border:1px solid #ddd;padding:9px;text-align:left;vertical-align:top}
    th{background:#f3f5f7}code{overflow-wrap:anywhere}</style></head><body>
    <h1>Mini Web Security Agent</h1><p><b>Target:</b> {target}</p>
    <p><b>Generated:</b> {generated}</p><p><b>Pages scanned:</b> {count}</p>
    <p>{scope}</p><table><thead><tr><th>Severity</th><th>Finding</th><th>Page</th><th>Evidence</th><th>Recommendation</th></tr></thead>
    <tbody>{rows}</tbody></table></body></html>""".format(
        target=escape(report["target"]), generated=escape(report["generated_at"]),
        count=report["pages_scanned"], scope=escape(report["scope_note"]),
        rows="".join(rows)
    )
    path.write_text(html, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Small passive browser-based web security checker")
    parser.add_argument("--url", required=True, help="Authorized application URL")
    parser.add_argument("--max-pages", type=int, default=20)
    parser.add_argument("--out", default="security-report.json")
    parser.add_argument("--headed", action="store_true", help="Show Chromium while scanning")
    parser.add_argument("--storage-state", help="Optional Playwright storage-state JSON for an authorized test account")
    args = parser.parse_args()
    if not 1 <= args.max_pages <= 100:
        parser.error("--max-pages must be between 1 and 100")
    report = asyncio.run(scan(args))
    counts = {}
    for f in report["findings"]:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1
    print(f"Scanned {report['pages_scanned']} page(s). Findings: {counts}")
    print(f"Reports: {args.out} and {Path(args.out).with_suffix('.html')}")


if __name__ == "__main__":
    main()
